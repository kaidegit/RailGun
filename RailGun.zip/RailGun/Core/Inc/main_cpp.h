//
// Created by yekai on 2021/5/18.
//

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void main_cpp();

#ifdef __cplusplus
}
#endif


