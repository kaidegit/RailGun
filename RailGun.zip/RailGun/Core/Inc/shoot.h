//
// Created by yekai on 2021/5/22.
//

#ifndef RAILGUN_SHOOT_H
#define RAILGUN_SHOOT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

void Shoot(uint16_t dis, uint16_t angle);

void AutoShoot();

void Charge(uint16_t seconds);

#ifdef __cplusplus
}
#endif

#endif //RAILGUN_SHOOT_H
