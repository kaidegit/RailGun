/*
 * Copyright 2021 NXP
 * SPDX-License-Identifier: MIT
 */


#ifndef EVENTS_INIT_H_
#define EVENTS_INIT_H_
#include "gui_guider.h"

#ifdef __cplusplus
extern "C" {
#endif

void events_init(lv_ui *ui);

#ifdef __cplusplus
}
#endif
#endif /* EVENT_CB_H_ */